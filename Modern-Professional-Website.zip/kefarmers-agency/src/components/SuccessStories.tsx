import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const SuccessStories = () => {
  const stories = [
    {
      id: 'story1',
      farmer: 'Mary Njeri',
      location: 'Kiambu County',
      story: 'After joining the KEFARMERS program, my maize yield increased by 45%. The irrigation techniques and quality seedlings made all the difference. My family now has a stable income and we\'ve improved our home.',
      imageSrc: '/images/tech-woman.jpg',
      tags: ['Maize Farming', 'Irrigation']
    },
    {
      id: 'story2',
      farmer: 'John Kamau',
      location: 'Nakuru County',
      story: 'Access to market information through the mobile app helped me sell my produce at 30% higher prices. I no longer depend on middlemen and can plan my planting seasons better with the weather updates.',
      imageSrc: '/images/farmer-mobile.jpg',
      tags: ['Market Access', 'Technology']
    },
    {
      id: 'story3',
      farmer: 'Sarah Wanjiku',
      location: 'Nairobi County',
      story: 'The training on climate-smart agriculture transformed my small urban farm. I now grow drought-resistant crops and use solar-powered irrigation. My income has doubled since implementing these techniques.',
      imageSrc: '/images/solar-irrigation.jpg',
      tags: ['Climate-Smart', 'Urban Farming']
    },
    {
      id: 'story4',
      farmer: 'Daniel Ochieng',
      location: 'Kisumu County',
      story: 'The microloan program enabled me to purchase quality fertilizers and hire additional help during harvest season. I\'ve been able to increase my production area and diversify my crops, improving my farm\'s resilience.',
      imageSrc: '/images/farmer-maize.jpg',
      tags: ['Financing', 'Diversification']
    }
  ];

  return (
    <section id="success-stories" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-green-800 mb-4">Farmer Success Stories</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            See how our solutions have transformed the lives of smallholder farmers across Kenya.
          </p>
        </div>

        <Tabs defaultValue="gallery" className="max-w-5xl mx-auto">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="gallery" className="text-sm md:text-base">
              Image Gallery
            </TabsTrigger>
            <TabsTrigger value="stories" className="text-sm md:text-base">
              Farmer Stories
            </TabsTrigger>
          </TabsList>

          {/* Gallery View */}
          <TabsContent value="gallery" className="mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {stories.map((story) => (
                <div
                  key={story.id}
                  className="relative group overflow-hidden rounded-lg shadow-md h-64 cursor-pointer"
                >
                  <Image
                    src={story.imageSrc}
                    alt={`${story.farmer} from ${story.location}`}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-80">
                    <div className="absolute bottom-0 p-4 text-white">
                      <h3 className="font-bold text-lg">{story.farmer}</h3>
                      <p className="text-sm text-gray-200">{story.location}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Stories View */}
          <TabsContent value="stories" className="mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {stories.map((story) => (
                <Card key={story.id} className="overflow-hidden">
                  <div className="relative h-48">
                    <Image
                      src={story.imageSrc}
                      alt={`${story.farmer} from ${story.location}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-bold text-lg text-green-700">{story.farmer}</h3>
                        <p className="text-sm text-gray-500">{story.location}</p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {story.tags.map((tag) => (
                          <span key={tag} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                    <p className="text-gray-700">{story.story}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-12 text-center">
          <p className="text-lg text-gray-700 italic max-w-3xl mx-auto">
            "KEFARMERS AGENCY has not only improved our agricultural techniques but has transformed entire communities by creating sustainable livelihoods."
          </p>
          <div className="mt-4">
            <span className="font-medium text-green-700">- Kenyan Agricultural Research Institute</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;
